# Keep companion app classes
-keep class com.spikecompanion.pro.** { *; }
