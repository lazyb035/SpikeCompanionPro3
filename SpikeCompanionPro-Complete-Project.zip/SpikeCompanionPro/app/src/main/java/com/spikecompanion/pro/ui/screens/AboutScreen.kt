package com.spikecompanion.pro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.SportsVolleyball
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.spikecompanion.pro.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxSize().background(DarkNavy)) {
        TopAppBar(
            title = { Text("About", fontWeight = FontWeight.SemiBold) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = DeepNavy,
                titleContentColor = TextPrimary,
                navigationIconContentColor = NeonBlue
            )
        )

        LazyColumn(
            contentPadding = PaddingValues(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(RoundedCornerShape(20.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(ElectricBlue.copy(0.3f), NeonBlue.copy(0.15f))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.SportsVolleyball,
                        contentDescription = null,
                        tint = NeonBlue,
                        modifier = Modifier.size(44.dp)
                    )
                }
            }
            item {
                Text(
                    "Spike Companion Pro",
                    style = MaterialTheme.typography.headlineMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
            item {
                Text(
                    "Version 1.0.0",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardBackground),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            "What this app is",
                            style = MaterialTheme.typography.titleMedium,
                            color = NeonBlue,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "A legitimate local companion application for players of The Spike Cross. It provides:\n\n" +
                                    "• Local Player ID storage\n" +
                                    "• Manual match statistics tracking\n" +
                                    "• Personal notes\n" +
                                    "• Optional floating overlay for quick access\n\n" +
                                    "It does not modify, inject into, or interact with the official game in any way.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
            }
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CardBackground),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            "Technically Unavailable Features",
                            style = MaterialTheme.typography.titleMedium,
                            color = WarningAmber,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "• Real in-game currency / resource modification\n" +
                                    "• Character or skin unlocking\n" +
                                    "• Stat editing or no-cooldown\n" +
                                    "• Any form of game memory injection or APK replacement\n" +
                                    "• Network traffic interception\n" +
                                    "• Bypassing official payment or authentication\n\n" +
                                    "These require invasive techniques that violate game ToS and are intentionally not implemented.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
            }
            item {
                Text(
                    "Inspired by professional gaming platform aesthetics.\nBuilt with Jetpack Compose & Material 3.\nNot affiliated with SUNCYAN Inc.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
