package com.spikecompanion.pro

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import com.spikecompanion.pro.data.PreferencesManager
import com.spikecompanion.pro.ui.navigation.AppNavigation
import com.spikecompanion.pro.ui.overlay.FloatingOverlayService
import com.spikecompanion.pro.ui.theme.DarkNavy
import com.spikecompanion.pro.ui.theme.SpikeCompanionTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var prefs: PreferencesManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        prefs = PreferencesManager(applicationContext)

        setContent {
            SpikeCompanionTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DarkNavy
                ) {
                    val isRegistered by prefs.isRegistered.collectAsStateWithLifecycle(initialValue = false)
                    val playerId by prefs.playerId.collectAsStateWithLifecycle(initialValue = "")
                    val wins by prefs.totalWins.collectAsStateWithLifecycle(initialValue = 0)
                    val losses by prefs.totalLosses.collectAsStateWithLifecycle(initialValue = 0)
                    val notes by prefs.notes.collectAsStateWithLifecycle(initialValue = "")
                    val overlayEnabled by prefs.overlayEnabled.collectAsStateWithLifecycle(initialValue = false)

                    AppNavigation(
                        isRegistered = isRegistered,
                        playerId = playerId,
                        wins = wins,
                        losses = losses,
                        notes = notes,
                        overlayEnabled = overlayEnabled,
                        onRegister = { id ->
                            lifecycleScope.launch {
                                prefs.registerPlayerId(id)
                            }
                        },
                        onAddWin = {
                            lifecycleScope.launch { prefs.addWin() }
                        },
                        onAddLoss = {
                            lifecycleScope.launch { prefs.addLoss() }
                        },
                        onSaveNotes = { text ->
                            lifecycleScope.launch { prefs.saveNotes(text) }
                        },
                        onToggleOverlay = { enabled ->
                            lifecycleScope.launch {
                                prefs.setOverlayEnabled(enabled)
                                if (enabled) {
                                    startService(Intent(this@MainActivity, FloatingOverlayService::class.java))
                                } else {
                                    stopService(Intent(this@MainActivity, FloatingOverlayService::class.java))
                                }
                            }
                        },
                        onClearRegistration = {
                            lifecycleScope.launch { prefs.clearRegistration() }
                        }
                    )
                }
            }
        }
    }
}
