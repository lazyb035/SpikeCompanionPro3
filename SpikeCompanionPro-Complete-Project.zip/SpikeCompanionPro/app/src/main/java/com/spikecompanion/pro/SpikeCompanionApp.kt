package com.spikecompanion.pro

import android.app.Application

class SpikeCompanionApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
