package com.spikecompanion.pro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.spikecompanion.pro.ui.components.FeatureCard
import com.spikecompanion.pro.ui.theme.*

data class ModFeature(
    val title: String,
    val description: String,
    val icon: ImageVector,
    val isAvailable: Boolean = false
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModsScreen(
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val features = listOf(
        ModFeature(
            "Unlimited Money",
            "In-game currency modification is not supported by this companion.",
            Icons.Default.AttachMoney
        ),
        ModFeature(
            "Unlimited Blue Flames",
            "Premium currency cannot be modified. Local companion only.",
            Icons.Default.Whatshot
        ),
        ModFeature(
            "Unlimited Upgrade Materials",
            "Resource modification is unavailable and not implemented.",
            Icons.Default.Construction
        ),
        ModFeature(
            "Unlock All Characters",
            "Character unlocks require official game progress or purchases.",
            Icons.Default.People
        ),
        ModFeature(
            "Unlock All Skins",
            "Skins are obtained through official game systems only.",
            Icons.Default.Palette
        ),
        ModFeature(
            "Custom Character Statistics",
            "Stat editing is not possible without game modification (unsupported).",
            Icons.Default.Tune
        ),
        ModFeature(
            "No Cooldown",
            "Cooldown removal would require injection and is not available.",
            Icons.Default.TimerOff
        ),
        ModFeature(
            "Ad-free Experience",
            "Ad removal is not provided. Use official options if available.",
            Icons.Default.Block
        )
    )

    Column(modifier = modifier.fillMaxSize().background(DarkNavy)) {
        TopAppBar(
            title = {
                Text(
                    "Mods Catalogue",
                    fontWeight = FontWeight.SemiBold
                )
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = DeepNavy,
                titleContentColor = TextPrimary,
                navigationIconContentColor = NeonBlue
            )
        )

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Technical Notice",
                            style = MaterialTheme.typography.titleSmall,
                            color = WarningAmber,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "None of the features below can be activated. This companion app does not inject code, modify game memory, intercept traffic, or alter The Spike Cross in any way. All listed items are shown for catalogue completeness and are permanently marked Unavailable.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }
            }

            items(features) { feature ->
                FeatureCard(
                    title = feature.title,
                    description = feature.description,
                    icon = feature.icon,
                    isAvailable = feature.isAvailable
                )
            }

            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Want real companion tools? Use Statistics and Notes sections to track your matches manually.",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted
                )
            }
        }
    }
}
