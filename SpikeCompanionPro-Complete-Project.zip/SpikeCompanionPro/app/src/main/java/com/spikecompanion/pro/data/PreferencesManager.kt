package com.spikecompanion.pro.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "spike_companion_prefs")

class PreferencesManager(private val context: Context) {

    companion object {
        private val PLAYER_ID = stringPreferencesKey("player_id")
        private val IS_REGISTERED = booleanPreferencesKey("is_registered")
        private val TOTAL_WINS = intPreferencesKey("total_wins")
        private val TOTAL_LOSSES = intPreferencesKey("total_losses")
        private val NOTES = stringPreferencesKey("notes")
        private val OVERLAY_ENABLED = booleanPreferencesKey("overlay_enabled")
        private val DEVICE_INFO = stringPreferencesKey("device_info")
    }

    val playerId: Flow<String> = context.dataStore.data.map { it[PLAYER_ID] ?: "" }
    val isRegistered: Flow<Boolean> = context.dataStore.data.map { it[IS_REGISTERED] ?: false }
    val totalWins: Flow<Int> = context.dataStore.data.map { it[TOTAL_WINS] ?: 0 }
    val totalLosses: Flow<Int> = context.dataStore.data.map { it[TOTAL_LOSSES] ?: 0 }
    val notes: Flow<String> = context.dataStore.data.map { it[NOTES] ?: "" }
    val overlayEnabled: Flow<Boolean> = context.dataStore.data.map { it[OVERLAY_ENABLED] ?: false }

    suspend fun registerPlayerId(id: String) {
        context.dataStore.edit { prefs ->
            prefs[PLAYER_ID] = id.trim()
            prefs[IS_REGISTERED] = true
            prefs[DEVICE_INFO] = android.os.Build.MODEL
        }
    }

    suspend fun clearRegistration() {
        context.dataStore.edit { prefs ->
            prefs[PLAYER_ID] = ""
            prefs[IS_REGISTERED] = false
        }
    }

    suspend fun addWin() {
        context.dataStore.edit { prefs ->
            prefs[TOTAL_WINS] = (prefs[TOTAL_WINS] ?: 0) + 1
        }
    }

    suspend fun addLoss() {
        context.dataStore.edit { prefs ->
            prefs[TOTAL_LOSSES] = (prefs[TOTAL_LOSSES] ?: 0) + 1
        }
    }

    suspend fun setWins(value: Int) {
        context.dataStore.edit { it[TOTAL_WINS] = value.coerceAtLeast(0) }
    }

    suspend fun setLosses(value: Int) {
        context.dataStore.edit { it[TOTAL_LOSSES] = value.coerceAtLeast(0) }
    }

    suspend fun saveNotes(text: String) {
        context.dataStore.edit { it[NOTES] = text }
    }

    suspend fun setOverlayEnabled(enabled: Boolean) {
        context.dataStore.edit { it[OVERLAY_ENABLED] = enabled }
    }
}
