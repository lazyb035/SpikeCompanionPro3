package com.spikecompanion.pro.ui.theme

import androidx.compose.ui.graphics.Color

val Black = Color(0xFF000000)
val DarkNavy = Color(0xFF0A0E1A)
val DeepNavy = Color(0xFF0D1421)
val CardBackground = Color(0xFF121826)
val SurfaceDark = Color(0xFF1A2332)
val SurfaceElevated = Color(0xFF222D3F)

val ElectricBlue = Color(0xFF00B4FF)
val NeonBlue = Color(0xFF00E5FF)
val BlueFlame = Color(0xFF4FC3F7)
val CyanAccent = Color(0xFF18FFFF)
val SoftBlue = Color(0xFF64B5F6)

val TextPrimary = Color(0xFFE8F1FF)
val TextSecondary = Color(0xFFA0B4D0)
val TextMuted = Color(0xFF6B7C94)

val SuccessGreen = Color(0xFF00E676)
val WarningAmber = Color(0xFFFFC107)
val ErrorRed = Color(0xFFFF5252)
val UnavailableGray = Color(0xFF546E7A)
