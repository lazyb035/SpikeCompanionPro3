package com.spikecompanion.pro.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.spikecompanion.pro.ui.screens.*

@Composable
fun AppNavigation(
    isRegistered: Boolean,
    playerId: String,
    wins: Int,
    losses: Int,
    notes: String,
    overlayEnabled: Boolean,
    onRegister: (String) -> Unit,
    onAddWin: () -> Unit,
    onAddLoss: () -> Unit,
    onSaveNotes: (String) -> Unit,
    onToggleOverlay: (Boolean) -> Unit,
    onClearRegistration: () -> Unit
) {
    val navController = rememberNavController()
    val startDestination = if (isRegistered) "dashboard" else "register"

    NavHost(
        navController = navController,
        startDestination = startDestination
    ) {
        composable("register") {
            RegistrationScreen(
                onRegistered = { id ->
                    onRegister(id)
                    navController.navigate("dashboard") {
                        popUpTo("register") { inclusive = true }
                    }
                }
            )
        }

        composable("dashboard") {
            DashboardScreen(
                playerId = playerId,
                wins = wins,
                losses = losses,
                onNavigate = { route -> navController.navigate(route) }
            )
        }

        composable("mods") {
            ModsScreen(onBack = { navController.popBackStack() })
        }

        composable("stats") {
            StatsScreen(
                wins = wins,
                losses = losses,
                onAddWin = onAddWin,
                onAddLoss = onAddLoss,
                onBack = { navController.popBackStack() }
            )
        }

        composable("notes") {
            NotesScreen(
                initialNotes = notes,
                onSave = onSaveNotes,
                onBack = { navController.popBackStack() }
            )
        }

        composable("settings") {
            SettingsScreen(
                playerId = playerId,
                overlayEnabled = overlayEnabled,
                onToggleOverlay = onToggleOverlay,
                onClearRegistration = {
                    onClearRegistration()
                    navController.navigate("register") {
                        popUpTo(0) { inclusive = true }
                    }
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable("about") {
            AboutScreen(onBack = { navController.popBackStack() })
        }

        composable("overlay") {
            // Reuse settings for overlay controls
            SettingsScreen(
                playerId = playerId,
                overlayEnabled = overlayEnabled,
                onToggleOverlay = onToggleOverlay,
                onClearRegistration = onClearRegistration,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
