package com.spikecompanion.pro.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.spikecompanion.pro.data.MatchHistoryStore
import com.spikecompanion.pro.data.MatchResult
import com.spikecompanion.pro.ui.components.StatCard
import com.spikecompanion.pro.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsScreen(
    wins: Int,
    losses: Int,
    onAddWin: () -> Unit,
    onAddLoss: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val total = wins + losses
    val winRate = if (total > 0) (wins * 100f / total) else 0f
    var history by remember { mutableStateOf(MatchHistoryStore.getAll()) }
    var showAddDialog by remember { mutableStateOf(false) }
    var isWin by remember { mutableStateOf(true) }

    Column(modifier = modifier.fillMaxSize().background(DarkNavy)) {
        TopAppBar(
            title = { Text("Match Statistics", fontWeight = FontWeight.SemiBold) },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            },
            actions = {
                IconButton(onClick = { showAddDialog = true }) {
                    Icon(Icons.Default.Add, contentDescription = "Add Result", tint = NeonBlue)
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = DeepNavy,
                titleContentColor = TextPrimary,
                navigationIconContentColor = NeonBlue
            )
        )

        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    StatCard(title = "Total Wins", value = wins.toString(), modifier = Modifier.weight(1f))
                    StatCard(title = "Total Losses", value = losses.toString(), modifier = Modifier.weight(1f))
                }
            }
            item {
                StatCard(
                    title = "Win Rate",
                    value = "%.1f%%".format(winRate),
                    subtitle = "$total matches recorded",
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            onAddWin()
                            MatchHistoryStore.add(MatchResult(result = "Win"))
                            history = MatchHistoryStore.getAll()
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen.copy(alpha = 0.2f), contentColor = SuccessGreen),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Add Win")
                    }
                    Button(
                        onClick = {
                            onAddLoss()
                            MatchHistoryStore.add(MatchResult(result = "Loss"))
                            history = MatchHistoryStore.getAll()
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = ErrorRed.copy(alpha = 0.2f), contentColor = ErrorRed),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Add Loss")
                    }
                }
            }

            item {
                Text(
                    "Match History (Local)",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary,
                    fontWeight = FontWeight.SemiBold
                )
            }

            if (history.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CardBackground),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "No matches recorded yet.\nTap the buttons above to log results manually.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextMuted,
                            modifier = Modifier.padding(20.dp)
                        )
                    }
                }
            } else {
                items(history) { match ->
                    MatchHistoryItem(match)
                }
            }
        }
    }
}

@Composable
private fun MatchHistoryItem(match: MatchResult) {
    val dateFormat = remember { SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()) }
    Card(
        colors = CardDefaults.cardColors(containerColor = CardBackground),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = match.result,
                    style = MaterialTheme.typography.titleSmall,
                    color = if (match.result == "Win") SuccessGreen else ErrorRed,
                    fontWeight = FontWeight.SemiBold
                )
                Text(
                    text = dateFormat.format(Date(match.timestamp)),
                    style = MaterialTheme.typography.bodySmall,
                    color = TextMuted
                )
            }
            if (match.score.isNotEmpty()) {
                Text(match.score, color = TextSecondary, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
