package com.spikecompanion.pro.data

import java.util.UUID

data class MatchResult(
    val id: String = UUID.randomUUID().toString(),
    val result: String, // "Win" or "Loss"
    val opponent: String = "",
    val score: String = "",
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

// Simple in-memory + preferences backed history for this companion
object MatchHistoryStore {
    private val history = mutableListOf<MatchResult>()

    fun add(result: MatchResult) {
        history.add(0, result) // newest first
        if (history.size > 50) history.removeLast()
    }

    fun getAll(): List<MatchResult> = history.toList()

    fun clear() {
        history.clear()
    }
}
