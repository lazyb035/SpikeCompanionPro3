# Spike Companion Pro

**Legitimate local gaming companion for The Spike Cross**

A polished Android application built with Kotlin + Jetpack Compose.  
Inspired by modern gaming platform aesthetics (dark theme, electric blue accents, card-based UI).

---

## Important Legal & Technical Notice

This application **does not**:

- Modify, inject into, or hook The Spike Cross
- Replace the official APK or damage save data
- Intercept network traffic
- Provide working cheats, unlimited currency, unlocks, or any game-altering functionality
- Bypass authentication or payment systems

All items listed under “Mods Catalogue” are permanently marked **Unavailable**.  
They exist only for catalogue completeness and UI demonstration.

**Real features provided:**

- Local Player ID registration & storage (SharedPreferences / DataStore)
- Manual match statistics (wins / losses / win rate / history)
- Personal notes
- Optional draggable floating overlay for quick access to companion tools
- Clean dark gaming UI with Material 3

---

## Requirements

- Android Studio Ladybug (2024.2.1) or newer recommended
- JDK 17
- Android SDK 35
- Min SDK 26 (Android 8.0)

---

## How to Build & Run

1. Open the project folder `SpikeCompanionPro` in Android Studio.
2. Let Gradle sync (first sync may take a few minutes).
3. Connect a device or start an emulator (API 26+).
4. Click **Run**.

### Generate APK

```bash
./gradlew assembleRelease
```

APK will be located at:

```
app/build/outputs/apk/release/app-release-unsigned.apk
```

Sign it with your keystore for distribution.

---

## Project Structure

```
app/src/main/java/com/spikecompanion/pro/
├── MainActivity.kt
├── SpikeCompanionApp.kt
├── data/
│   ├── PreferencesManager.kt      # DataStore for Player ID, stats, notes
│   └── MatchHistory.kt
├── ui/
│   ├── theme/                     # Colors, Typography, Theme
│   ├── components/                # FeatureCard, StatCard
│   ├── screens/                   # All main screens
│   ├── navigation/                # NavHost
│   └── overlay/                   # FloatingOverlayService
```

---

## Features Implemented

| Feature                    | Status      | Notes                                      |
|---------------------------|-------------|--------------------------------------------|
| Player ID Registration    | ✅ Working  | Local only                                 |
| Dashboard                 | ✅ Working  | Stats overview + navigation cards          |
| Mods Catalogue            | ✅ Working  | All items clearly marked Unavailable       |
| Match Statistics          | ✅ Working  | Manual add Win/Loss + history              |
| Quick Notes               | ✅ Working  | Local text storage                         |
| Floating Overlay          | ✅ Working  | Requires SYSTEM_ALERT_WINDOW permission    |
| Settings                  | ✅ Working  | Overlay toggle, clear registration         |
| About                     | ✅ Working  | Full disclosure of limitations             |
| Dark gaming theme         | ✅ Working  | Electric blue / navy aesthetic             |
| Animations & polish       | ✅ Working  | Card borders, switches, transitions        |

---

## Technically Unavailable (Intentionally)

- Unlimited Money / Blue Flames / Materials
- Unlock All Characters / Skins
- Custom Character Statistics
- No Cooldown
- Ad removal via this app
- Any form of game process injection or memory editing

These require invasive techniques that violate the game’s Terms of Service and are not implemented.

---

## Permissions

- `SYSTEM_ALERT_WINDOW` – optional, only for the floating bubble
- `FOREGROUND_SERVICE` + `SPECIAL_USE` – keeps the overlay service alive while active
- `POST_NOTIFICATIONS` – required on Android 13+ for the foreground notification

No internet permission is requested. The app works fully offline.

---

## Compatibility with The Spike Cross

The app is designed to run **alongside** the official Google Play / Steam version of The Spike Cross.  
It never uninstalls, replaces, or interferes with the original game.

---

Built with care as a legitimate companion tool.

---

## Build with GitHub Actions (Recommended for APK)

This repository includes a ready-to-use GitHub Actions workflow that builds the debug APK on a cloud runner with sufficient RAM.

### Steps

1. Create a new public or private repository on GitHub.
2. Push this entire project to the repository (main or master branch).
3. Go to the **Actions** tab of your repository.
4. Select the workflow **"Build Debug APK"**.
5. Click **Run workflow** → **Run workflow**.
6. Wait for the job to finish (usually 3–6 minutes).
7. When the job succeeds, open the completed run.
8. Under **Artifacts**, download **app-debug-apk**.
9. Unzip the artifact — inside you will find `app-debug.apk`.
10. Transfer the APK to your Android phone and install it (enable “Install from unknown sources” if needed).

### Notes

- The workflow uses `ubuntu-latest`, JDK 17, and `assembleDebug`.
- The APK is unsigned debug build (fine for personal testing).
- No secrets or authentication beyond your GitHub account are required.
- If the build fails, open the failed job log, copy the error, and share it so the source can be fixed.

